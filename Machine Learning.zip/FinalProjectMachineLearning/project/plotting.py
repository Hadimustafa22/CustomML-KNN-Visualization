import matplotlib.pyplot as plt


def plot_roc_curve(fpr, tpr, roc_auc, classifier_name):
    plt.figure()
    plt.plot(fpr, tpr, label=f'{classifier_name} (AUC = {roc_auc:.4f})')
    plt.plot([0, 1], [0, 1], 'k--', label='Random Guess')
    plt.xlabel('False Positive Rate (FPR)')
    plt.ylabel('True Positive Rate (TPR)')
    plt.title('Receiver Operating Characteristic (ROC) Curve')
    plt.legend(loc='lower right')
    plt.grid()
    plt.savefig(f'{classifier_name}_ROC.png')  # Save the plot as an image file
