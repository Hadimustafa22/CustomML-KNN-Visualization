import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve, roc_auc_score
# Import the plotting function from the separate file
from plotting import plot_roc_curve
# Step 1: Load the Titanic dataset
data = pd.read_csv(
    'c:\\Users\\hadim\\Desktop\\FinalProjectMachineLearning\\project\\train.csv')


# Step 2: Data Preprocessing
# Drop irrelevant columns (e.g., PassengerId, Name, Ticket, Cabin)
data.drop(['PassengerId', 'Name', 'Ticket', 'Cabin'], axis=1, inplace=True)

# Handle missing values
data['Age'].fillna(data['Age'].median(), inplace=True)
data['Embarked'].fillna(data['Embarked'].mode()[0], inplace=True)

# Convert categorical features to numerical
label_encoder = LabelEncoder()
data['Sex'] = label_encoder.fit_transform(data['Sex'])
data['Embarked'] = label_encoder.fit_transform(data['Embarked'])

# Split data into features (X) and labels (y)
X = data.drop('Survived', axis=1)
y = data['Survived']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

# Step 3: Implement Classifiers
# Initialize classifiers
decision_tree = DecisionTreeClassifier(random_state=42)
svc = SVC(random_state=42, probability=True)  # Set probability=True
logistic_regression = LogisticRegression(random_state=42)
knn = KNeighborsClassifier()

# Step 4: Calculate ROC Curve and AUC for each classifier
classifiers = [decision_tree, svc, logistic_regression, knn]
classifier_names = ['Decision Tree', 'SVC', 'Logistic Regression', 'KNN']

for clf, name in zip(classifiers, classifier_names):
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    y_prob = clf.predict_proba(X_test)[:, 1]

    # Calculate ROC Curve and AUC
    fpr, tpr, thresholds = roc_curve(y_test, y_prob)
    roc_auc = roc_auc_score(y_test, y_prob)

    # Call the plotting function to generate and save the ROC curve plot
    plot_roc_curve(fpr, tpr, roc_auc, name)

    # Evaluate classifier performance
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)

    # Print results
    print(f'{name} Classifier:')
    print(f'Accuracy: {accuracy:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, F1-score: {f1:.4f}, ROC-AUC: {roc_auc:.4f}')
    print()
