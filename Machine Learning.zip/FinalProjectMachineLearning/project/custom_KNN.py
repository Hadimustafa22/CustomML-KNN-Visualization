import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

# Step 1: Load the Titanic dataset
data = pd.read_csv(
    'c:\\Users\\hadim\\Desktop\\FinalProjectMachineLearning\\project\\train.csv')

# Step 2: Data Preprocessing
# Drop irrelevant columns (e.g., PassengerId, Name, Ticket, Cabin)
data.drop(['PassengerId', 'Name', 'Ticket', 'Cabin'], axis=1, inplace=True)

# Handle missing values
data['Age'].fillna(data['Age'].median(), inplace=True)
data['Embarked'].fillna(data['Embarked'].mode()[0], inplace=True)

# Convert categorical features to numerical
label_encoder = LabelEncoder()
data['Sex'] = label_encoder.fit_transform(data['Sex'])
data['Embarked'] = label_encoder.fit_transform(data['Embarked'])

# Split data into features (X) and labels (y)
X = data.drop('Survived', axis=1)
y = data['Survived']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

# Step 3: Implement custom KNN algorithm


def euclidean_distance(x1, x2):
    return np.sqrt(np.sum((x1 - x2) ** 2))


def knn_predict(X_train, y_train, X_test, k):
    y_pred = []

    for i in range(len(X_test)):
        distances = []
        for j in range(len(X_train)):
            dist = euclidean_distance(
                X_test.iloc[i].values, X_train.iloc[j].values)
            distances.append((dist, y_train.iloc[j]))

        distances.sort(key=lambda x: x[0])
        k_nearest_neighbors = distances[:k]
        k_nearest_labels = [neighbor[1] for neighbor in k_nearest_neighbors]
        prediction = max(set(k_nearest_labels), key=k_nearest_labels.count)
        y_pred.append(prediction)

    return y_pred


# Step 4: Making predictions using custom KNN
k = 5  # Choosing any value of K
y_pred_knn = knn_predict(X_train, y_train, X_test, k)

# Step 5: Evaluate custom KNN
accuracy = accuracy_score(y_test, y_pred_knn)
precision = precision_score(y_test, y_pred_knn)
recall = recall_score(y_test, y_pred_knn)
f1 = f1_score(y_test, y_pred_knn)
roc_auc = roc_auc_score(y_test, y_pred_knn)

# Print results
print(f'Custom KNN Classifier (K = {k}):')
print(f'Accuracy: {accuracy:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, F1-score: {f1:.4f}, ROC-AUC: {roc_auc:.4f}')
